<b>Sayın Yağız MAKTAV,<u></u><u></u></b></p><p class="MsoNormal" style="margin-bottom:8.0pt;text-align:justify;line-height:105%"><b><u></u>&nbsp;<u></u></b></p><p 
### Website: www.akinsoftjobtest.netlify.app
### Task : https://mail.google.com/mail/u/0/?pli=1#inbox/FMfcgzGqPphQkKPzGDGWqcwtcVDGKGKq?projector=1&messagePartId=0.1


Sayın Yağız MAKTAV,

 

Yapmış olduğunuz iş başvurunuza istinaden, değerlendirilmek üzere hazırlamanız gereken proje mail ekinde tarafınıza gönderilmiştir.

Ek’te gönderilen projeyi en geç 1 gün içerisinde tamamladıktan sonra aynı mail üzerinden yanıtla/cevapla yoluyla geri göndermenizi rica ederiz.

 

AKINROBOTICS İnsansı Robot Fabrikası

Adres;

Başak Mahallesi Konya Ereğli Caddesi No: 116 Karatay/KONYA